#!/usr/bin/env bash

set -x
exec > >(tee -i /tmp/fgmod-install.log) 2>&1

error_exit() {
  echo " $1"
  if [[ -n $STEAM_ZENITY ]]; then
    $STEAM_ZENITY --error --text "$1"
  else 
    zenity --error --text "$1" || echo "Zenity failed to display error"
  fi
  logger -t fgmod "ERROR: $1"
  exit 1
}

# === CONFIG ===
fgmod_path="$HOME/fgmod"
dll_name="${DLL:-dxgi.dll}"
preserve_ini="${PRESERVE_INI:-true}"
fsr4_variant="${FGMOD_FSR4_VARIANT:-}"
python_bin="$(command -v python3 || command -v python || true)"

# === Resolve Game Path ===
if [[ "$#" -lt 1 ]]; then
  error_exit "Usage: $0 program [program_arguments...]"
fi

exe_folder_path=""
if [[ $# -eq 1 ]]; then
  [[ "$1" == *.exe ]] && exe_folder_path=$(dirname "$1") || exe_folder_path="$1"
else
  for arg in "$@"; do
    if [[ "$arg" == *.exe ]]; then
      [[ "$arg" == *"Cyberpunk 2077"* ]] && arg=${arg//REDprelauncher.exe/bin/x64/Cyberpunk2077.exe}
      [[ "$arg" == *"Witcher 3"* ]]      && arg=${arg//REDprelauncher.exe/bin/x64_dx12/witcher3.exe}
      [[ "$arg" == *"Baldurs Gate 3"* ]] && arg=${arg//Launcher\/LariLauncher.exe/bin/bg3_dx11.exe}
      [[ "$arg" == *"HITMAN 3"* ]]       && arg=${arg//Launcher.exe/Retail/HITMAN3.exe}
      [[ "$arg" == *"HITMAN World of Assassination"* ]] && arg=${arg//Launcher.exe/Retail/HITMAN3.exe}
      [[ "$arg" == *"SYNCED"* ]]         && arg=${arg//Launcher\/sop_launcher.exe/SYNCED.exe}
      [[ "$arg" == *"2KLauncher"* ]]     && arg=${arg//2KLauncher\/LauncherPatcher.exe/DoesntMatter.exe}
      [[ "$arg" == *"Warhammer 40,000 DARKTIDE"* ]] && arg=${arg//launcher\/Launcher.exe/binaries/Darktide.exe}
      [[ "$arg" == *"Warhammer Vermintide 2"* ]]    && arg=${arg//launcher\/Launcher.exe/binaries_dx12/vermintide2_dx12.exe}
      [[ "$arg" == *"Satisfactory"* ]]   && arg=${arg//FactoryGameSteam.exe/Engine/Binaries/Win64/FactoryGameSteam-Win64-Shipping.exe}
      [[ "$arg" == *"FINAL FANTASY XIV Online"* ]] && arg=${arg//boot\/ffxivboot.exe/game/ffxiv_dx11.exe}
      exe_folder_path=$(dirname "$arg")
      break
    fi
  done
fi

for arg in "$@"; do
  if [[ "$arg" == lutris:rungameid/* ]]; then
    lutris_id="${arg#lutris:rungameid/}"

    # Get slug from Lutris JSON
    slug=$(lutris --list-games --json 2>/dev/null | jq -r ".[] | select(.id == $lutris_id) | .slug")

    if [[ -z "$slug" || "$slug" == "null" ]]; then
      echo "Could not find slug for Lutris ID $lutris_id"
      break
    fi

    # Find matching YAML file using slug
    config_file=$(find ~/.config/lutris/games/ -iname "${slug}-*.yml" | head -1)

    if [[ -z "$config_file" ]]; then
      echo "No config file found for slug '$slug'"
      break
    fi

    # Extract executable path from YAML
    exe_path=$(grep -E '^\s*exe:' "$config_file" | sed 's/.*exe:[[:space:]]*//' )

    if [[ -n "$exe_path" ]]; then
      exe_folder_path=$(dirname "$exe_path")
      echo "Resolved executable path: $exe_path"
      echo "Executable folder: $exe_folder_path"
    else
      echo "Executable path not found in $config_file"
    fi

    break
  fi
done

[[ -z "$exe_folder_path" && -n "$STEAM_COMPAT_INSTALL_PATH" ]] && exe_folder_path="$STEAM_COMPAT_INSTALL_PATH"

if [[ -d "$exe_folder_path/Engine" ]]; then
  ue_exe=$(find "$exe_folder_path" -maxdepth 4 -mindepth 4 -path "*Binaries/Win64/*.exe" -not -path "*/Engine/*" | head -1)
  exe_folder_path=$(dirname "$ue_exe")
fi

[[ ! -d "$exe_folder_path" ]] && error_exit " Could not resolve game directory!"
[[ ! -w "$exe_folder_path" ]] && error_exit " No write permission to the game folder!"

logger -t fgmod "Target directory: $exe_folder_path"
logger -t fgmod "Using DLL name: $dll_name"
logger -t fgmod "Preserve INI: $preserve_ini"

proxy_backup_files=(
  "dxgi.dll"
  "winmm.dll"
  "dbghelp.dll"
  "version.dll"
  "wininet.dll"
  "winhttp.dll"
  "OptiScaler.asi"
)

cleanup_files=(
  "${proxy_backup_files[@]}"
  "OptiScaler.dll"
  "nvngx.dll"
  "_nvngx.dll"
  "nvngx-wrapper.dll"
  "nvngx.ini"
  "dlss-enabler.dll"
  "dlss-enabler-upscaler.dll"
  "fakenvapi.log"
  "OptiScaler.log"
  "dlssg_to_fsr3.log"
  "dlssg_to_fsr3_amd_is_better-3.0.dll"
)

is_bundled_proxy_copy() {
  local existing_file="$1"
  local bundled_copy="$fgmod_path/renames/$(basename "$existing_file")"
  [[ -f "$existing_file" && -f "$bundled_copy" ]] && cmp -s "$existing_file" "$bundled_copy"
}

has_patch_fingerprint() {
  local fingerprint
  for fingerprint in "FRAMEGEN_PATCH" "OptiScaler.ini" "fakenvapi.dll" "fakenvapi.ini" "dlssg_to_fsr3_amd_is_better.dll" "D3D12_Optiscaler"; do
    [[ -e "$exe_folder_path/$fingerprint" ]] && return 0
  done
  return 1
}

resolve_fsr4_variant() {
  if [[ -n "$fsr4_variant" ]]; then
    echo "$fsr4_variant"
    return
  fi

  local manifest_path="$fgmod_path/install-manifest.json"
  if [[ -f "$manifest_path" && -n "$python_bin" ]]; then
    local manifest_variant
    manifest_variant=$("$python_bin" - <<PY 2>/dev/null
import json
from pathlib import Path
path = Path(r'''$manifest_path''')
try:
    data = json.loads(path.read_text(encoding='utf-8'))
    value = str(data.get('selected_default_variant') or '').strip()
    print(value)
except Exception:
    pass
PY
)
    if [[ -n "$manifest_variant" ]]; then
      echo "$manifest_variant"
      return
    fi
  fi

  echo "rdna23-int8"
}

selected_fsr4_variant="$(resolve_fsr4_variant)"
variant_dir=""
variant_extra_files=()
variant_ini_overrides=()
case "$selected_fsr4_variant" in
  rdna4-native)
    variant_dir="$fgmod_path/fsr4-rdna4"
    fsr4_upscaler_src="$variant_dir/amd_fidelityfx_upscaler_dx12.dll"
    ;;
  rdna34-official-411)
    variant_dir="$fgmod_path/fsr4-rdna3-4-official-411"
    fsr4_upscaler_src="$variant_dir/amd_fidelityfx_upscaler_dx12.dll"
    variant_extra_files+=("amdxcffx64.dll")
    ;;
  rdna2-valve-411-pre10)
    variant_dir="$fgmod_path/fsr4-rdna2-valve-411-pre10"
    fsr4_upscaler_src="$variant_dir/amd_fidelityfx_upscaler_dx12.dll"
    variant_extra_files+=("amdxcffx64.dll" "amdxc64.dll")
    variant_ini_overrides+=("FSR.Fsr4ForceModel=2")
    variant_ini_overrides+=("Plugins.LoadCustomAmdxc64OnRdna2=true")
    ;;
  helixsr)
    # HelixSR itself lives in the game's HelixSR/ folder (set up by the plugin's patch);
    # the game root keeps the INT8 FSR4 upscaler, which stays selectable next to it.
    variant_dir="$fgmod_path/fsr4-rdna2-3"
    fsr4_upscaler_src="$variant_dir/amd_fidelityfx_upscaler_dx12.dll"
    ;;
  *)
    selected_fsr4_variant="rdna23-int8"
    variant_dir="$fgmod_path/fsr4-rdna2-3"
    fsr4_upscaler_src="$variant_dir/amd_fidelityfx_upscaler_dx12.dll"
    ;;
esac
[[ -f "$fsr4_upscaler_src" ]] || fsr4_upscaler_src="$fgmod_path/amd_fidelityfx_upscaler_dx12.dll"
logger -t fgmod "Using FSR4 variant: $selected_fsr4_variant (source: $fsr4_upscaler_src)"

is_managed_support_file() {
  local existing_file="$1"
  local filename
  filename="$(basename "$existing_file")"
  local candidate
  if [[ "$filename" == "amd_fidelityfx_upscaler_dx12.dll" ]]; then
    for candidate in \
      "$fgmod_path/amd_fidelityfx_upscaler_dx12.dll" \
      "$fgmod_path/fsr4-rdna2-3/amd_fidelityfx_upscaler_dx12.dll" \
      "$fgmod_path/fsr4-rdna4/amd_fidelityfx_upscaler_dx12.dll" \
      "$fgmod_path/fsr4-rdna3-4-official-411/amd_fidelityfx_upscaler_dx12.dll" \
      "$fgmod_path/fsr4-rdna2-valve-411-pre10/amd_fidelityfx_upscaler_dx12.dll"; do
      [[ -f "$candidate" && -f "$existing_file" ]] && cmp -s "$existing_file" "$candidate" && return 0
    done
    return 1
  fi
  if [[ "$filename" == "amdxcffx64.dll" ]]; then
    for candidate in \
      "$fgmod_path/amdxcffx64.dll" \
      "$fgmod_path/fsr4-rdna3-4-official-411/amdxcffx64.dll" \
      "$fgmod_path/fsr4-rdna2-valve-411-pre10/amdxcffx64.dll"; do
      [[ -f "$candidate" && -f "$existing_file" ]] && cmp -s "$existing_file" "$candidate" && return 0
    done
    return 1
  fi
  if [[ "$filename" == "amdxc64.dll" ]]; then
    for candidate in \
      "$fgmod_path/fsr4-rdna2-valve-411-pre10/amdxc64.dll"; do
      [[ -f "$candidate" && -f "$existing_file" ]] && cmp -s "$existing_file" "$candidate" && return 0
    done
    return 1
  fi
  candidate="$fgmod_path/$filename"
  [[ -f "$candidate" && -f "$existing_file" ]] && cmp -s "$existing_file" "$candidate"
}

# === Backup Pre-existing Proxy DLLs Before Cleanup ===
for dll in "${proxy_backup_files[@]}"; do
  existing_path="$exe_folder_path/$dll"
  backup_path="$exe_folder_path/$dll.b"
  if [[ -f "$existing_path" && ! -f "$backup_path" ]]; then
    if has_patch_fingerprint || is_bundled_proxy_copy "$existing_path"; then
      logger -t fgmod "Skipping backup for managed/stale proxy copy: $dll"
    else
      mv -f "$existing_path" "$backup_path"
      echo " Backed up pre-existing $dll"
      logger -t fgmod "Backed up pre-existing proxy file: $dll"
    fi
  fi
done
unset existing_path backup_path fingerprint

# === Cleanup Old Injectors / Legacy OptiScaler Artifacts ===
for cleanup_file in "${cleanup_files[@]}"; do
  rm -f "$exe_folder_path/$cleanup_file"
done
unset cleanup_file

# === Optional: Backup Original DLLs ===
original_dlls=("d3dcompiler_47.dll" "amd_fidelityfx_dx12.dll" "amd_fidelityfx_framegeneration_dx12.dll" "amd_fidelityfx_upscaler_dx12.dll" "amdxcffx64.dll" "amdxc64.dll" "amd_fidelityfx_vk.dll")
for dll in "${original_dlls[@]}"; do
  existing_path="$exe_folder_path/$dll"
  backup_path="$exe_folder_path/$dll.b"
  if [[ -f "$existing_path" && ! -f "$backup_path" ]]; then
    if has_patch_fingerprint && is_managed_support_file "$existing_path"; then
      rm -f "$existing_path"
      logger -t fgmod "Removed managed support file before repatch: $dll"
    else
      mv -f "$existing_path" "$backup_path"
      logger -t fgmod "Backed up original game DLL: $dll"
    fi
  fi
done
unset existing_path backup_path

# === Remove nvapi64.dll and its backup (conflicts from previous fakenvapi versions) ===
rm -f "$exe_folder_path/nvapi64.dll" "$exe_folder_path/nvapi64.dll.b"
echo " Cleaned up nvapi64.dll and backup (legacy fakenvapi conflicts)"

# === Core Install ===
if [[ -n "$variant_dir" && -f "$variant_dir/renames/$dll_name" ]]; then
  echo " Using variant pre-renamed $dll_name"
  cp "$variant_dir/renames/$dll_name" "$exe_folder_path/$dll_name" || error_exit " Failed to copy variant $dll_name"
elif [[ -n "$variant_dir" && -f "$variant_dir/OptiScaler.dll" ]]; then
  echo " Using variant OptiScaler injector"
  cp "$variant_dir/OptiScaler.dll" "$exe_folder_path/$dll_name" || error_exit " Failed to copy variant OptiScaler.dll as $dll_name"
elif [[ -f "$fgmod_path/renames/$dll_name" ]]; then
  echo " Using pre-renamed $dll_name"
  cp "$fgmod_path/renames/$dll_name" "$exe_folder_path/$dll_name" || error_exit " Failed to copy $dll_name"
else
  echo " Pre-renamed $dll_name not found, falling back to OptiScaler.dll"
  cp "$fgmod_path/OptiScaler.dll" "$exe_folder_path/$dll_name" || error_exit " Failed to copy OptiScaler.dll as $dll_name"
fi

# === OptiScaler.ini Handling ===
if [[ "$preserve_ini" == "true" && -f "$exe_folder_path/OptiScaler.ini" ]]; then
  echo " Preserving existing OptiScaler.ini (user settings retained)"
  logger -t fgmod "Existing OptiScaler.ini preserved in $exe_folder_path"
else
  echo " Installing OptiScaler.ini from plugin defaults"
  cp "$fgmod_path/OptiScaler.ini" "$exe_folder_path/OptiScaler.ini" || error_exit " Failed to copy OptiScaler.ini"
  logger -t fgmod "OptiScaler.ini installed to $exe_folder_path"
fi

# === OptiScaler env variables Handling ===
if [[ -f "$fgmod_path/update-optiscaler-config.py" ]]; then
  python "$fgmod_path/update-optiscaler-config.py" "$exe_folder_path/OptiScaler.ini"
fi

# OptiScaler 0.9.0-pre11 can assert on Proton when HQ font auto mode tries to load
# an external TTF that is not present. Only normalize the default auto value.
sed -i 's/^UseHQFont[[:space:]]*=[[:space:]]*auto$/UseHQFont=false/' "$exe_folder_path/OptiScaler.ini" || true

if [[ ${#variant_ini_overrides[@]} -gt 0 && -n "$python_bin" ]]; then
  "$python_bin" - "$exe_folder_path/OptiScaler.ini" "${variant_ini_overrides[@]}" <<'PY'
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
overrides = sys.argv[2:]
content = path.read_text(encoding='utf-8', errors='replace')
newline = '\r\n' if '\r\n' in content else '\n'
lines = content.splitlines(keepends=True)
section_pattern = re.compile(r'^\s*\[(?P<section>[^\]]+)\]\s*$')

def ensure_trailing_newline():
    if lines and not lines[-1].endswith(('\n', '\r')):
        lines[-1] += newline

def upsert(section, key, value):
    replacement = f'{key}={value}'
    key_pattern = re.compile(rf'^(\s*{re.escape(key)}\s*)=.*$')
    if section is None:
        for idx, line in enumerate(lines):
            if key_pattern.match(line):
                line_ending = '\r\n' if line.endswith('\r\n') else ('\n' if line.endswith('\n') else newline)
                lines[idx] = f'{replacement}{line_ending}'
                return
        ensure_trailing_newline()
        lines.append(f'{replacement}{newline}')
        return

    in_section = False
    insert_at = None
    for idx, line in enumerate(lines):
        match = section_pattern.match(line.strip())
        if match:
            if in_section:
                insert_at = idx
                break
            if match.group('section') == section:
                in_section = True
                continue
        if in_section and key_pattern.match(line):
            line_ending = '\r\n' if line.endswith('\r\n') else ('\n' if line.endswith('\n') else newline)
            lines[idx] = f'{replacement}{line_ending}'
            return

    if in_section:
        if insert_at is None:
            ensure_trailing_newline()
            insert_at = len(lines)
        lines.insert(insert_at, f'{replacement}{newline}')
        return

    ensure_trailing_newline()
    if lines and lines[-1].strip():
        lines.append(newline)
    lines.append(f'[{section}]{newline}')
    lines.append(f'{replacement}{newline}')

for override in overrides:
    key_part, value = override.split('=', 1)
    if '.' in key_part:
        section, key = key_part.split('.', 1)
    else:
        section, key = None, key_part
    if key:
        upsert(section.strip() if section else None, key.strip(), value.strip())

path.write_text(''.join(lines), encoding='utf-8')
PY
fi

# === Migrate FGType → FGInput/FGOutput (pre-v0.9-final INIs) ===
# v0.9-final split the single FGType key into FGInput + FGOutput. Games that were
# patched with an older build will have FGType=<value> with no FGInput/FGOutput,
# causing the new DLL to silently use nofg. Fix that here on every launch.
_fgtype_ini="$exe_folder_path/OptiScaler.ini"
if grep -q '^FGType=' "$_fgtype_ini" 2>/dev/null; then
  _fgtype_val=$(sed -n 's/^FGType=\(.*\)/\1/p' "$_fgtype_ini")
  echo " Migrating FGType=$_fgtype_val → FGInput/FGOutput in OptiScaler.ini"
  logger -t fgmod "Migrating FGType=$_fgtype_val → FGInput/FGOutput"
  if grep -q '^FGInput=' "$_fgtype_ini"; then
    # FGInput already present — INI already in v0.9-final format; just drop FGType
    sed -i '/^FGType=/d' "$_fgtype_ini" || true
  else
    # Replace FGType=X with FGInput=X + FGOutput=X
    sed -i "s/^FGType=.*$/FGInput=$_fgtype_val\nFGOutput=$_fgtype_val/" "$_fgtype_ini" || true
  fi
fi
unset _fgtype_ini _fgtype_val

# === ASI Plugins Directory ===
if [[ -d "$fgmod_path/plugins" ]]; then
  echo " Installing ASI plugins directory"
  cp -r "$fgmod_path/plugins" "$exe_folder_path/" || true
  logger -t fgmod "ASI plugins directory installed to $exe_folder_path"
else
  echo " No plugins directory found in fgmod"
fi

# === D3D12_Optiscaler Directory (required for FSR4/FidelityFX DX12 path) ===
if [[ -d "$fgmod_path/D3D12_Optiscaler" ]]; then
  echo " Installing D3D12_Optiscaler directory"
  cp -r "$fgmod_path/D3D12_Optiscaler" "$exe_folder_path/" || true
  logger -t fgmod "D3D12_Optiscaler directory installed to $exe_folder_path"
else
  echo " No D3D12_Optiscaler directory found in fgmod"
fi

# === Supporting Libraries ===
cp -f "$fgmod_path/libxess.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/libxess_dx11.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/libxess_fg.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/libxell.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/amd_fidelityfx_dx12.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/amd_fidelityfx_framegeneration_dx12.dll" "$exe_folder_path/" || true
cp -f "$fsr4_upscaler_src" "$exe_folder_path/amd_fidelityfx_upscaler_dx12.dll" || true
for variant_extra_file in "${variant_extra_files[@]}"; do
  if [[ -f "$variant_dir/$variant_extra_file" ]]; then
    cp -f "$variant_dir/$variant_extra_file" "$exe_folder_path/" || true
  fi
done
cp -f "$fgmod_path/amd_fidelityfx_vk.dll" "$exe_folder_path/" || true

# === Nukem FG Mod Files (now in fgmod directory) ===
cp -f "$fgmod_path/dlssg_to_fsr3_amd_is_better.dll" "$exe_folder_path/" || true
# Note: dlssg_to_fsr3.ini is not included in v0.9.0-final archive

# === FakeNVAPI Files ===
# Remove legacy nvapi64.dll to avoid conflicts
# rm -f "$exe_folder_path/nvapi64.dll"
# echo " Removed legacy nvapi64.dll"

# Copy fakenvapi.dll with original name (v1.3.8.1) 
cp -f "$fgmod_path/fakenvapi.dll" "$exe_folder_path/" || true
cp -f "$fgmod_path/fakenvapi.ini" "$exe_folder_path/" || true
echo " Installed fakenvapi.dll and fakenvapi.ini"

# === Additional Support Files ===
# cp -f "$fgmod_path/d3dcompiler_47.dll" "$exe_folder_path/" || true

# Note: d3dcompiler_47.dll is not included in v0.9.0-final archive

echo " Installation completed successfully!"
echo " For Steam, add this to the launch options: \"$fgmod_path/fgmod\" %COMMAND%"
echo " For Heroic, add this as a new wrapper: \"$fgmod_path/fgmod\""
logger -t fgmod "Installation completed successfully for $exe_folder_path"

# === Execute original command ===
if [[ $# -gt 1 ]]; then
  # Log to both file and system journal
  logger -t fgmod "=================="
  logger -t fgmod "Debug Info (Launch Mode):"
  logger -t fgmod "Number of arguments: $#"
  for i in $(seq 1 $#); do
    logger -t fgmod "Arg $i: ${!i}"
  done
  logger -t fgmod "Final executable path: $exe_folder_path"
  logger -t fgmod "=================="
  
  # Execute the original command
  export SteamDeck=0
  # Build WINEDLLOVERRIDES from the actual proxy DLL name (strip extension to get the stem)
  if [[ "$dll_name" == *.dll ]]; then
    _wine_dll="${dll_name%.dll}"
    export WINEDLLOVERRIDES="$WINEDLLOVERRIDES,${_wine_dll}=n,b"
    unset _wine_dll
  fi
  # .asi files are loaded by an ASI loader — no WINEDLLOVERRIDES entry needed

  # Filter out leading -- separators (from Steam launch options)
  while [[ $# -gt 0 && "$1" == "--" ]]; do
    shift
  done

  exec >/dev/null 2>&1
  "$@"
else
  echo "Done!"
  echo "----------------------------------------"
  echo "Debug Info (Standalone Mode):"
  echo "Number of arguments: $#"
  for i in $(seq 1 $#); do
    echo "Arg $i: ${!i}"
  done
  echo "Final executable path: $exe_folder_path"
  echo "----------------------------------------"
  
  # Also log standalone mode to journal
  logger -t fgmod "=================="
  logger -t fgmod "Debug Info (Standalone Mode):"
  logger -t fgmod "Number of arguments: $#"
  for i in $(seq 1 $#); do
    logger -t fgmod "Arg $i: ${!i}"
  done
  logger -t fgmod "Final executable path: $exe_folder_path"
  logger -t fgmod "=================="
fi
