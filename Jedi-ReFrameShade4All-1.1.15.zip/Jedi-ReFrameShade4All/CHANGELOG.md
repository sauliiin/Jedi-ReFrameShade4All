# Changelog

## 1.1.15

### Added
- **Plugin Update** at the bottom of the panel: it checks this plugin's newest GitHub release (`get_plugin_update_status`) and installs it through Decky's own installer, which asks to confirm, checks the zip against GitHub's SHA256 and reloads the plugin.

### Changed
- Shorter Patch All intro, and the second "Pick a game" line above the game list is gone.
- The "This game still uses the runtime above. Press Patch All to switch it to HelixSR." warning is gone from the game status.

### Removed
- **Choose exe/folder path** (manual `.exe`/folder patching for non-Steam games), its file browser and every message pointing to it. Advanced controls now act on the game picked at the top. Non-Steam shortcuts that start a launcher (Heroic, Lutris, …) are no longer listed, since they can't be patched without that picker. Backend: `manual_patch_directory`, `manual_unpatch_directory`, `remove_optiscaler_only_manual`, `remove_reshade_only_manual`, `install_reshade_for_heroic_game`, `uninstall_reshade_for_heroic_game`, `detect_heroic_game_api`, `browse_filesystem_for_executable`, `get_sd_card_mount_path`, `validate_windows_executable_path`, `get_path_defaults`, `unpatch_game` and the Heroic helpers.

### Fixed
- **Remove All**, **Remove only OptiScaler** and **Remove only ReShade** left files behind:
  - They only cleaned one folder: OptiScaler's first marker, and ReShade the folder the target detection guessed at removal time. Patches made to another target `.exe`, or a folder whose marker was lost, stayed patched. They now go through every folder of the game.
  - A re-patch stashed ReShade's `d3dcompiler_47.dll` link as an "original" `d3dcompiler_47.dll.b`, and removing OptiScaler later put it back. OptiScaler's patch and unpatch now leave ReShade's links alone, and old `.b` copies of them are deleted.
  - ReShade removal now also deletes `ReShadePreset.ini` (the install creates it), dangling links left after ReShade itself was uninstalled, and ReShade DLLs the old manual install copied instead of linking.
  - Remove All handed back the launch options from the first patch even when you had changed them since. It now keeps your current ones minus this plugin's DLL overrides and `SteamDeck=0`.
- OptiScaler's unpatch deleted the game's whole `plugins` folder. It now removes only `OptiPatcher.asi`, and the folder only if nothing else is in it.
- Uninstalling OptiScaler also removes `.fgmod-staging-*` / `.fgmod-backup-*` folders left by interrupted installs.

## 1.1.14

### Fixed
- Patching with HelixSR failed with "There's already a HelixSR folder next to OptiScaler.ini that this plugin didn't create". A `HelixSR/` folder already in the game (left half made by an earlier patch, or made by another tool) is now replaced by the plugin's own, and the patch message says what was there. The plugin made the folder first and its record of it (`jedi-helixsr.json`) last, so a patch that stopped half way left such a folder: a patch that fails now removes the folder it made. Switching runtime or unpatching also removes a half-made folder, with OptiScaler.ini's paths into it set back to auto.

## 1.1.13

### Added
- **4.1.2 Lite | FSR4L-i8** upscaler runtime (experimental): AMD's FSR 4.1.2 INT8 Lite model, the smaller INT8 model AMD made for APUs (Steam Deck, RDNA2/3 iGPUs). It ships AMD's unmodified, signed Adrenalin 26.10.1 driver FSR (`amdxcffx64.dll` and, for Vulkan games, `amdvkffx64.dll`, 2.4.0.4370) with an OptiScaler 10 injector built from master `2128299c` (the first build that selects 4.1.2 models and keeps the AMD vendor id for `amdxcffx64` while spoofing). The FFX/XeSS libraries stay 0.9.4's: they are the same files in OptiScaler 10.
- Patching with it sets OptiScaler 10's keys (`Fsr4GpuSupport=4`, `Fsr4Model=3`, `Dx12Upscaler=ffx`, `UpscalerIndex=0`) and keeps Nukems frame generation working (`FGInput=NvngxFG`, `FGNvngxReplacement=Nukems`: OptiScaler 10 reads `FGInput=nukems` as no FG). Switching a game to another runtime puts the 0.9.4 values back.

### Fixed
- HelixSR 2.0.0 failed with "No HelixSR DLL found": 2.0 keeps the DLL in `HelixSR-fsrfg/`. The setup also stopped getting `--yes`, which 2.0 hands on to its game installer (it would have put HelixSR into every game it finds): the plugin downloads NVIDIA's DLSS DLL itself (checked against the release's own SHA256) and passes it with `--dlss`, so the build asks nothing and the game installer changes no game.

## 1.1.12

### Added
- HelixSR download progress: the download (about 130 MB from HelixSR 1.9.3, which now bundles HelixSR Scaler), its SHA256 check and the extraction run in the background with a progress bar, followed by the build. A failed download is shown in the panel; the installed HelixSR stays untouched.

### Changed
- HelixSR Scaler (`helixsr-scaler/`, ~205 MB in HelixSR 1.9.3's zip) is no longer extracted: it isn't used here and the setup builds the network without it. An installed release now takes about 8 MB.
- Checked against HelixSR 1.9.3 and DeckyHelixSRManager 0.10.2: same setup flags, FSR4 forwarding and frame generation forwarding.

### Fixed
- The HelixSR build was started from a worker thread, which made the install report an error ("no current event loop") although the build was running.

## 1.1.11

### Added
- **HelixSR** as an upscaler runtime (*HelixSR | DLSS Model E on AMD*, experimental), ported from [DeckyHelixSRManager](https://github.com/PeroTuncay/DeckyHelixSRManager). Selecting it shows whether the newest HelixSR release is installed; if not, **Install/Update HelixSR** downloads it (SHA256-verified) and runs HelixSR's setup in the background with a progress bar (`get_helixsr_status`, `install_latest_helixsr`, `cancel_helixsr_setup`). Only one release is kept: a new build replaces the old one once it succeeds.
- Patching with HelixSR sets it as OptiScaler's FFX upscaler from a per-game `HelixSR/` folder (FSR4 4.0.2c stays selectable, frame generation keeps working); switching runtime or unpatching restores `OptiScaler.ini` and removes the folder.

### Changed
- The *FSR4 runtime* dropdown is now **Upscaler runtime (FSR4 / HelixSR)**.

### Fixed
- HelixSR not showing in OptiScaler's FFX Upscaler list (only FSR 4.0.2c did): in the game, HelixSR is now `helixsr.dll` / `helixsr_upscaler.dll`, so the loader no longer hands back the FSR DLL the game already loaded under the same name. Re-patch the game to apply.
- Old OptiScaler.ini template bug: an unanchored `Path=auto` → `Path=plugins` also set `OptiDllPath`, `NvapiPath`, `FfxDx12*Path`, `XeSSPath`, `TTFFontPath`, … to `plugins`. Only `[Plugins] Path` gets it now, and patching repairs existing game INIs.
- The game status shows the applied upscaler runtime and, for HelixSR, what `helixsr.log` reports (loaded / upscaling / network not running), with a **Check HelixSR again** button.

## 1.0.10

### Updated
- Bundled OptiScaler from `0.9.3-final` to the official `0.9.4-final.20260718` archive (FFX 2.3 SDK / FSR 4.1.1), matching Decky-Framegen `0.17`.
- FSR4 runtimes relabeled to match upstream: *4.0.2c RDNA2/3 Compatibility*, *4.1.1 FFX 2.3 SDK*, *4.1.1 Driver Override* and *4.1.1 Valve RDNA2 Compatibility*. The SDK, driver-override and Valve RDNA2 paths now all use the 0.9.4 FSR 4.1.1 upscaler.

### Added
- The FSR4 runtime dropdown now shows a short description of the selected runtime (ported from Decky-Framegen).
- **Non-Steam game detection**: shortcuts from Steam's `shortcuts.vdf` appear in the game picker. Direct `.exe` shortcuts support Patch All, per-engine patching, status and removal, with launch options applied to the shortcut automatically; launcher shortcuts (Heroic, Lutris, …) point the user to the manual exe picker. Broad folders (home, drive roots) are never scanned recursively.

### Fixed
- Variant extra DLLs (`amdxcffx64.dll`, `amdxc64.dll`) are only copied into the game folder when present.

## 1.0.9

### Added
- **Partial removal**, the counterpart of the existing "Apply only …" actions: **🗑️ Remove only OptiScaler** in *Framegen Management* and **🗑️ Remove only ReShade** in *ReShade Management*, both for Steam games and for manually chosen non‑Steam `.exe` folders (`remove_optiscaler_only`, `remove_reshade_only`, `remove_optiscaler_only_manual`, `remove_reshade_only_manual`).
- Removing one mod keeps the other working: the OptiScaler cleanup wipes every proxy slot, so ReShade is re‑linked on its slot afterwards. Launch options are rewritten for whatever remains (Steam games are updated automatically; non‑Steam users get the new launch command copied to the clipboard) and cleared when nothing remains.

## 1.0.8

### Added
- Ported Decky-Framegen `v0.16.3-pre` FSR4 runtime matrix: RDNA3/4 official 4.1.1 and experimental RDNA2 Valve 4.1.1 pre10 with its dedicated injector.
- Variant-aware patching now copies runtime extra DLLs, applies OptiScaler.ini overrides, detects variants by extra files, and exposes the new runtimes in the panel.

### Fixed
- Framegen unpatch/wrapper cleanup now handles `amdxcffx64.dll` and `amdxc64.dll` backups correctly.

## 1.0.7

### Updated
- Bundled OptiScaler from `0.9.2a` to the official `0.9.3-final.20260618` archive.
- Project and release references now point to Jedi‑ReFrameShade4All and the official OptiScaler release.

### Fixed
- OptiScaler install now resolves helper scripts from `defaults/assets` in sideload/store packages and fails clearly if any helper is missing.
- Missing runtime binaries are downloaded from the hash-pinned `remote_binary` manifest when necessary.
- Updates are prepared and validated in a staging directory before atomically replacing `~/fgmod`, preserving the previous install on failure.
- Explicit updates no longer fall back to the old bundled build while reporting success; downloaded release size and SHA-256 are verified.
- Legacy installs without an install manifest are correctly offered the current update.

## 1.0.0

First release — fusion of **OptiScaler Frame Generation** (Decky‑Framegen 0.15.6) and **ReShade with add‑ons** (LetMeReShade) into a single Decky plugin.

### Added
- Single back‑end (`main.py`) combining both projects via `_OptiScalerMixin` + `_ReShadeMixin` under one Decky `Plugin` class.
- **One‑button "Patch All"** primary flow (`patch_all_game` / `unpatch_all_game`): pick one Steam game → installs OptiScaler + ReShade engines if missing, patches both into the same folder (ReShade `dxgi` + Frame Generation `winmm`), and sets the merged launch options automatically. `get_engines_status` powers the status line. Detailed per‑engine controls now live under an **Advanced controls** toggle.
- **Coexistence layer** so both run on the same game: ReShade keeps the graphics slot (`dxgi`, auto‑detected); Frame Generation is forced onto `winmm`; launch options merge into a single `WINEDLLOVERRIDES`.
  - `get_combined_game_status`, `set_slots_manual`, and a **Coexistence / DLL slots** UI section with a manual slot picker.
- **FRAMEGEN MANAGEMENT** widget mirroring **RESHADE MANAGEMENT**: installed state, version, *up to date / update available*, and an Install/Update button. The FSR4 runtime is chosen once (top section) and shared.
- **Precise OptiScaler update check** (`get_optiscaler_update_status`): compares the installed archive **asset name** vs. the newest GitHub release asset (not the tag), so no false "update available". The **Update** button (`update_optiscaler`) force‑downloads the newest complete archive.
- Unified front‑end (`src/index.tsx`); plugin renamed to **Jedi ReFrameShade4All**.

### Fixed
- **"Asks to install again" loop**: caused by two concurrent install buttons writing to `~/fgmod`. Fixed by collapsing to a single install/update entry.
- **Duplicate install button**: removed the redundant "Install OptiScaler" widget that did the same thing as "Setup OptiScaler Mod".

### Removed
- Dead source files: `OptiScalerHeader`, `OptiScalerWiki`, `SteamGamePatcher`, `InstallationStatus`, `SteamGamesSection`, `HeroicGamesSection`, `InstalledGamesSection`, `exports.ts`.

### Inherited
- OptiScaler: FSR4 variants (incl. Steam Deck / RDNA2‑3 INT8), idempotent patch/unpatch, install manifest, Steam‑OS‑beta UI.
- ReShade: add‑on support, AutoHDR, shader pack selection, Steam + Heroic + manual `.exe` patching.

### Notes
- Not yet validated end‑to‑end on Steam Deck hardware.
- ReShade add‑on toggle ships **off** (anti‑cheat warning).
